console.log("Hello from script.js");
