console.log("Static file served successfully!");
